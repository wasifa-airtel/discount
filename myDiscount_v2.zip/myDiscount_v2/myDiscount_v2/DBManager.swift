//
//  DBManager.swift
//  myDiscount_v2
//
//  Created by wasifa ahmed on 12/12/17.
//  Copyright © 2017 wasifa ahmed. All rights reserved.
//

import UIKit

class DBManager: NSObject {

let field_deal_id="id"
let field_prod_name="product_name"
let field_des="description"
let field_expiry_date="expiry_date"
let field_prize="prize"
let field_discount="discount"
let field_cus_name="customer_name"
let field_unit="unit"
let field_dis_unit="dis_unit"
let field_store_name = "store_name"
    
static let shared: DBManager = DBManager()
    
//Database Name
let databaseFileName = "discount.sqlite"
var pathToDatabase: String!
var database: FMDatabase!
    
override init() {
        super.init()
        let documentsDirectory = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString) as String
        pathToDatabase = documentsDirectory.appending("/\(databaseFileName)")
    }
    
    func createDatabase() -> Bool {
        var created = false
        print("createDatabase")
        if !FileManager.default.fileExists(atPath: pathToDatabase) {
            database = FMDatabase(path: pathToDatabase!)
            
            if database != nil {
                // Open the database.
                if database.open() {
                    let createMoviesTableQuery = "CREATE TABLE IF NOT EXISTS tblt_my_deal (\(field_deal_id) integer primary key autoincrement not null, \(field_prod_name) text not null, \(field_des) text , \(field_expiry_date) text not null, \(field_prize) text not null, \(field_discount) text not null, \(field_cus_name) text not null,\(field_dis_unit) text not null,\(field_unit) text not null,\(field_store_name) text not null )"
                    
                    do {
                        try database.executeUpdate(createMoviesTableQuery, values: nil)
                        created = true
                    }
                    catch {
                        print("Could not create table.")
                        print(error.localizedDescription)
                    }
                    
                    database.close()
                }
                else {
                    print("Could not open the database.")
                }
            }
        }
        
        return created
    }
    
    
    
    
    func openDatabase() -> Bool {
        if database == nil {
            if FileManager.default.fileExists(atPath: pathToDatabase) {
                database = FMDatabase(path: pathToDatabase)
            }
        }
        
        if database != nil {
            if database.open() {
                return true
            }
        }
        
        return false
    }
    
    func insertData() {
        if openDatabase() {
            print("insertData")
            var query = ""
                do {
             
                    
                               query += "insert into tblt_my_deal (\(field_deal_id),\(field_prod_name), \(field_des), \(field_expiry_date), \(field_prize), \(field_discount), \(field_cus_name),\(field_unit),\(field_dis_unit),\(field_store_name)) values (null, 'pizza', ' ','2018-01-31', '6000', '3000', 'Saddam Hossain', 'BDT','BDT','Pizza Inn');"
                    
                               query += "insert into tblt_my_deal (\(field_deal_id),\(field_prod_name), \(field_des), \(field_expiry_date), \(field_prize), \(field_discount), \(field_cus_name),\(field_unit),\(field_dis_unit),\(field_store_name)) values (null, 'Coke', ' ','2018-02-01', '150', '70', 'Saddam Hossain', 'BDT','BDT','Agora');"
                    
                        
                        }
                            catch {
                                print(error.localizedDescription)
                        }
            
                    
                    if !database.executeStatements(query) {
                        print("Failed to insert initial data into the database.")
                        print(database.lastError(), database.lastErrorMessage())
                    }
                }
        
            database.close()
            }
    
    func loaditem() -> [Production]! {
        var items: [Production]!
        print("loaditems")
        if openDatabase() {
            let query = "select * from tblt_my_deal"
            print(query)
            do {
                print(database)
                let results = try database.executeQuery(query, values: nil)
                var disc_unit : String!
                var disc_bdt : String!
                var name : String!
                var prize_unit : String!
                var prize_bdt : String!
    
                
                while results.next() {
                  print(results)
                  prize_unit = results.string(forColumn: field_unit)
                  prize_bdt = results.string(forColumn: field_prize)
                  let prize_dec = prize_unit +  prize_bdt
                  
                  disc_unit = results.string(forColumn: field_dis_unit)
                  disc_bdt = results.string(forColumn: field_discount)
                  let disc_dec = disc_bdt + disc_unit
                  
                  name = results.string(forColumn: field_prod_name)
                  let search_dec = name  + prize_dec + disc_dec
                    
                  let item = Production(prod_name :results.string(forColumn: field_prod_name),
                                         prize :prize_dec,
                                         discount: disc_dec,
                                         exp_date: results.string(forColumn: field_expiry_date),
                                         search : search_dec
                                         )
            
                                          
                    
                    
                    if items == nil {
                        items = [Production]()
                    }
                    
                    items.append(item)
                }
            }
            catch {
                print(error.localizedDescription)
            }
            
            database.close()
        }
        
        return items
    }
    
    
    
            
        
        
}
    


