



import UIKit

struct Production {
    let prod_name : String!
    let prize : String!
    let  discount : String!
    let exp_date : String!
    let search : String!

}


class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchResultsUpdating {

    @IBOutlet var tableView: UITableView!
    
    
    var items : [Production]!
    
    
    var filteredItems : [Production]!
    
    let searchController = UISearchController(searchResultsController: nil)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var db_create = DBManager.shared.createDatabase()
        //var db_insert = DBManager.shared.insertData()
        items = DBManager.shared.loaditem()
      
        filteredItems = items
        
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
  
        
        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }

    
  
    
    
    func updateSearchResults(for searchController: UISearchController) {
        // If we haven't typed anything into the search bar then do not filter the results
        print("updateSearchResults")
        if searchController.searchBar.text! == "" {
            filteredItems = items
        } else {
        // Filter the results
            filteredItems = items.filter { $0.search.lowercased().contains(searchController.searchBar.text!.lowercased()) }

        }
        self.tableView.reloadData()
    }
    
  
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("filteredItems")
        print(filteredItems)
        //filteredItems=items
        return (filteredItems != nil) ? self.filteredItems.count : 0
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell 	{
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
   
        let list=self.filteredItems[indexPath.row]
        let Txt = list.prize
        let Txt1 = "  Discount : "
        let Txt2 = list.discount
        let Txt3 = "  Last Date : "
        let Txt4 = list.exp_date
        
        let text = Txt! + Txt1 + Txt2! + Txt3 + Txt4!
        
        cell.textLabel?.text = list.prod_name
        cell.detailTextLabel?.text = text

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Row \(indexPath.row) selected")
    }

}


