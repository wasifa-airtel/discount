//
//  DBManager.h
//  myDiscount_v2
//
//  Created by wasifa ahmed on 12/12/17.
//  Copyright © 2017 wasifa ahmed. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DBManager : NSObject

@end
